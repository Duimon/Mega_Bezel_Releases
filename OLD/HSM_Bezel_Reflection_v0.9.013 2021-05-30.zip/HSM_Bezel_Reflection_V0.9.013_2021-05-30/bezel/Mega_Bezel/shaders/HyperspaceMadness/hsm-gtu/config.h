#pragma parameter GTU_TITLE		"[ --- TV PROCESS GTU --- ]:" 0 0 0.01 0.01
#pragma parameter GTU_MODE      "          OFF | ON | Composite" 0 0 2 1

#define FIXNUM 6